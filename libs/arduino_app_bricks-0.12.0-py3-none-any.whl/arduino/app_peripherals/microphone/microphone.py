# SPDX-FileCopyrightText: Copyright (C) Arduino s.r.l. and/or its affiliated companies
#
# SPDX-License-Identifier: MPL-2.0

import numpy as np

from .base_microphone import BaseMicrophone, FormatPlain, FormatPacked


class Microphone:
    """
    Unified Microphone class that can be configured for different microphone types.

    This class serves as both a factory and a wrapper, automatically creating
    the appropriate microphone implementation based on the provided configuration.

    Supports:
        - ALSA Microphones (local microphones connected to the system via ALSA)
        - WebSocket Microphones (input audio streams via WebSocket client)

    Note: constructor arguments (except those in signature) must be provided in
    keyword format to forward them correctly to the specific microphone implementations.
    Refer to the documentation of each microphone type for available parameters.
    """

    """
    Constants for microphone configuration.

    Provides commonly used values for devices, sample rates, channels, and buffer sizes.
    Select appropriate values based on application requirements and hardware capabilities.
    """

    # =============================================================================
    # Predefined devices
    # =============================================================================
    USB_MIC_1 = "usb:1"
    """Shorthand for the first USB microphone available."""
    USB_MIC_2 = "usb:2"
    """Shorthand for the second USB microphone available."""
    JACK_MIC_1 = "jack:1"
    """Shorthand for the first built-in (jack) microphone available."""

    # =============================================================================
    # Sample Rate Constants
    # =============================================================================

    RATE_8K = 8000
    """8 kHz - Telephony bandwidth, VoIP applications"""

    RATE_16K = 16000
    """16 kHz - Common for voice processing, speech recognition, keyword spotting"""

    RATE_32K = 32000
    """32 kHz - Higher quality voice, some broadcast applications"""

    RATE_44K = 44100
    """44.1 kHz - CD quality audio standard"""

    RATE_48K = 48000
    """48 kHz - Professional audio, broadcast standard, high-quality recording"""

    # =============================================================================
    # Channel Constants
    # =============================================================================

    CHANNELS_MONO = 1
    """Mono - Single channel audio"""

    CHANNELS_STEREO = 2
    """Stereo - Two channel audio (left and right)"""

    # =============================================================================
    # Buffer Size Constants
    # =============================================================================

    BUFFER_SIZE_REALTIME = 256
    """
    Real-time/low-latency: ~16ms @ 16kHz, ~5ms @ 48kHz

    Use for: Live audio effects, real-time playback, low-latency voice chat
    Trade-off: Low latency but high CPU usage
    """

    BUFFER_SIZE_BALANCED = 1024
    """
    Balanced (default): ~64ms @ 16kHz, ~21ms @ 48kHz

    Use for: Voice commands, keyword spotting, general audio processing
    Trade-off: Good balance between latency and efficiency
    """

    BUFFER_SIZE_SAFE = 4096
    """
    Transcription/recording: ~256ms @ 16kHz, ~85ms @ 48kHz

    Use for: Speech recognition, transcription, recording, non-real-time processing
    Trade-off: High latency but low CPU usage
    """

    def __new__(
        cls,
        device: str | int | None = None,
        sample_rate: int = RATE_16K,
        channels: int = CHANNELS_MONO,
        format: FormatPlain | FormatPacked = np.int16,
        buffer_size: int = BUFFER_SIZE_BALANCED,
        **kwargs,
    ) -> BaseMicrophone:
        """
        Create a microphone instance based on the device type.

        Args:
            device (str | int | None): Microphone device identifier. Supports:
                - None: Auto-select the first available plugged microphone, i.e.
                    not already in use by another instance, giving priority to USB
                    microphones, then jack ones if supported by the platform.
                    Raises if every plugged microphone is already in use
                - int | str: Select the n-th plugged microphone (e.g., 0, 1, "0",
                    "1", ...) counting USB microphones first, then jack ones,
                    regardless of whether it is already in use: contention on a
                    reused microphone is only discovered when starting it
                - str: ALSA device name (e.g., "plughw:CARD=MyCard,DEV=0", "hw:0,0", "CARD=MyCard,DEV=0")
                - str: ALSA device file path (e.g., "/dev/snd/by-id/usb-My-Device-00")
                - str: Microphone.USB_MIC_x / Microphone.JACK_MIC_x macros
                - str: WebSocket URL for audio streams (e.g., "ws://0.0.0.0:8080")
                Default: None.
            sample_rate (int): Sample rate in Hz. Default: 16000
            channels (int): Number of audio channels. Default: 1
            format (FormatPlain | FormatPacked): Audio format as one of:
                - Type classes: np.int16, np.float32, np.uint8
                - dtype objects: np.dtype('<i2'), np.dtype('>f4')
                - Strings: 'int16', '<i2', '>f4', 'float32'
                - Tuple of (format, is_packed): to specify if the format is packed (e.g. 24-bit audio)
                Default: np.int16 - 16-bit signed platform-endian.
            buffer_size (int): Size of the audio buffer. Default: 1024.
            **kwargs: Microphone-specific configuration parameters grouped by type:
                ALSA Microphone Parameters:
                    shared (bool): Whether the microphone can be used by multiple applications
                        simultaneously. Default: True.
                    auto_reconnect (bool): Whether to automatically attempt to reconnect
                        if the microphone connection is lost. Default: True.
                WebSocket Microphone Parameters:
                    port (int): WebSocket server port. Default: 8080
                    timeout (float): Connection timeout in seconds. Default: 3.0
                    certs_dir_path (str): Path to the directory containing TLS certificates.
                    use_tls (bool): Enable TLS for secure connections. If True, 'encrypt' will
                        be ignored. Use this for transport-level security with clients that can
                        accept self-signed certificates or when supplying your own certificates.
                    secret (str | None): Pre-shared secret key. None disables security.
                        Default: None.
                    encrypt (bool): Enable encryption. Requires a secret, raises
                        RuntimeError otherwise. Default: False.
                    auto_reconnect (bool): Whether to automatically attempt to reconnect
                        if the microphone connection is lost. Default: True.

        Returns:
            BaseMicrophone: Appropriate microphone implementation instance

        Raises:
            MicrophoneConfigError: If microphone type is not supported or parameters are invalid
            MicrophoneOpenError: If no microphone is available at the requested index

        Examples:
            ALSA Microphone:

            ```python
            microphone = Microphone(sample_rate=16000, channels=1)  # First plugged microphone
            microphone = Microphone(Microphone.USB_MIC_1, sample_rate=16000, channels=1)  # First USB microphone
            microphone = Microphone(Microphone.JACK_MIC_1)  # First built-in (jack) microphone
            microphone = Microphone(1)  # Second plugged microphone
            microphone = Microphone("CARD=MyCard,DEV=0", format="S16_LE")
            microphone = Microphone("plughw:CARD=MyCard,DEV=0")
            microphone = Microphone("hw:0,0")
            microphone = Microphone("/dev/snd/by-id/usb-My-Device-00")  # Using device file path
            microphone = Microphone("pipewire")  # To use default PipeWire microphone (if available)
            microphone = Microphone("pipewire:NODE=MyPipewireNode")  # Using PipeWire node name
            ```

            WebSocket Microphone:

            ```python
            microphone = Microphone("ws://0.0.0.0:8080", sample_rate=48000)
            microphone = Microphone("ws://0.0.0.0:8080", secret="topsecret", encrypt=True)
            ```
        """
        from .utils import _microphone_registry

        if device is None:
            # Auto-selection: claim the first available microphone so other instances don't select it
            from .utils import _claim_first_available_microphone

            device = _claim_first_available_microphone()
            try:
                mic = _create_microphone(device, sample_rate, channels, format, buffer_size, **kwargs)
            except BaseException:
                _microphone_registry.release(device)
                raise
            _microphone_registry.bind(device, mic)
            return mic

        if not isinstance(device, (str, int)):
            from .errors import MicrophoneConfigError

            raise MicrophoneConfigError(f"Invalid device type: {type(device)}")

        mic = _create_microphone(device, sample_rate, channels, format, buffer_size, **kwargs)

        from .alsa_microphone import ALSAMicrophone

        if isinstance(mic, ALSAMicrophone):
            # Claim local devices so auto-selection doesn't pick them
            _microphone_registry.claim(mic.device_stable_ref)
            _microphone_registry.bind(mic.device_stable_ref, mic)
        return mic

    @staticmethod
    def record_pcm(duration: float, sample_rate: int, channels: int, format: FormatPlain | FormatPacked, device: str | int = 0) -> np.ndarray:
        """
        Record audio for a specified duration and return as raw PCM format.

        Args:
            duration (float): Recording duration in seconds.
            sample_rate (int): Sample rate in Hz.
            channels (int): Number of audio channels.
            format (FormatPlain | FormatPacked): Audio format as one of:
                - Type classes: np.int16, np.float32, np.uint8
                - dtype objects: np.dtype('<i2'), np.dtype('>f4')
                - Strings: 'int16', '<i2', '>f4', 'float32'
                - Tuple of (format, is_packed): to specify if the format is packed (e.g. 24-bit audio)
            device (Union[str, int]): Microphone device identifier. Supports:
                - int | str: Select the n-th plugged microphone (e.g., 0, 1, "0",
                    "1", ...) counting USB microphones first, then jack ones if
                    supported by the platform. The device is shared with other
                    instances using it
                - str: ALSA device name (e.g., "plughw:CARD=MyCard,DEV=0", "hw:0,0", "CARD=MyCard,DEV=0")
                - str: ALSA device file path (e.g., "/dev/snd/by-id/usb-My-Device-00")
                - str: Microphone.USB_MIC_x / Microphone.JACK_MIC_x macros
                - str: WebSocket URL for audio streams (e.g., "ws://0.0.0.0:8080")
                Default: 0.

        Returns:
            np.ndarray: Raw audio data in raw PCM format.

        Raises:
            MicrophoneOpenError: If microphone can't be opened.
            MicrophoneReadError: If no audio is available after multiple attempts.
            ValueError: If duration is not > 0.
            Exception: If the underlying implementation fails to read a frame.
        """
        with Microphone(
            device=device,
            sample_rate=sample_rate,
            channels=channels,
            format=format,
        ) as mic:
            return mic.record_pcm(duration=duration)

    @staticmethod
    def record_wav(duration: float, sample_rate: int, channels: int, format: FormatPlain | FormatPacked, device: str | int = 0) -> np.ndarray:
        """
        Record audio for a specified duration and return as WAV format.
        Note: Only uncompressed PCM WAV recordings are supported.

        Args:
            duration (float): Recording duration in seconds.
            sample_rate (int): Sample rate in Hz.
            channels (int): Number of audio channels.
            format (FormatPlain | FormatPacked): Audio format as one of:
                - Type classes: np.int16, np.float32, np.uint8
                - dtype objects: np.dtype('<i2'), np.dtype('>f4')
                - Strings: 'int16', '<i2', '>f4', 'float32'
                - Tuple of (format, is_packed): to specify if the format is packed (e.g. 24-bit audio)
            device (Union[str, int], optional): Microphone device identifier. Supports:
                - int | str: Select the n-th plugged microphone (e.g., 0, 1, "0",
                    "1", ...) counting USB microphones first, then jack ones if
                    supported by the platform. The device is shared with other
                    instances using it
                - str: ALSA device name (e.g., "plughw:CARD=MyCard,DEV=0", "hw:0,0", "CARD=MyCard,DEV=0")
                - str: ALSA device file path (e.g., "/dev/snd/by-id/usb-My-Device-00")
                - str: Microphone.USB_MIC_x / Microphone.JACK_MIC_x macros
                - str: WebSocket URL for audio streams (e.g., "ws://0.0.0.0:8080")
                Default: 0.

        Returns:
            np.ndarray: Raw audio data in WAV format as numpy array.

        Raises:
            MicrophoneOpenError: If microphone can't be opened.
            MicrophoneReadError: If no audio is available after multiple attempts.
            ValueError: If duration is not > 0.
            Exception: If the underlying implementation fails to read a frame.
        """
        with Microphone(
            device=device,
            sample_rate=sample_rate,
            channels=channels,
            format=format,
        ) as mic:
            return mic.record_wav(duration=duration)


def _create_microphone(
    device: str | int,
    sample_rate: int,
    channels: int,
    format: FormatPlain | FormatPacked,
    buffer_size: int,
    **kwargs,
) -> BaseMicrophone:
    """Create the microphone implementation matching the given device identifier."""
    from urllib.parse import urlparse

    parsed = urlparse(device) if isinstance(device, str) else None
    if parsed is not None and parsed.scheme in ["ws", "wss"]:
        from .websocket_microphone import WebSocketMicrophone  # Imported here to avoid circular dependency

        # WebSocket Microphone
        port = parsed.port if parsed.port is not None else 8080
        mic = WebSocketMicrophone(
            port=port,
            sample_rate=sample_rate,
            channels=channels,
            format=format,
            buffer_size=buffer_size,
            **kwargs,
        )
        if parsed.hostname != "0.0.0.0":
            mic.logger.warning(f"Ignoring bind addresses other than '0.0.0.0' ({parsed.hostname}).")
        return mic
    else:
        from .alsa_microphone import ALSAMicrophone  # Imported here to avoid circular dependency

        # ALSA Microphone
        return ALSAMicrophone(
            device=device,
            sample_rate=sample_rate,
            channels=channels,
            format=format,
            buffer_size=buffer_size,
            **kwargs,
        )
