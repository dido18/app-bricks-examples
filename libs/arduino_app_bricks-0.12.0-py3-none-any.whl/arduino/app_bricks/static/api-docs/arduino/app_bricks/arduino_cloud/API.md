# arduino_cloud API Reference

## Index

- Class `ArduinoCloud`
- Class `Location`
- Class `Color`
- Class `ColoredLight`
- Class `DimmedLight`
- Class `Schedule`

---

## `ArduinoCloud` class

```python
class ArduinoCloud(device_id: str, secret: str, server: str, port: int, daemon_url: str)
```

Arduino Cloud client for exchanging variables with the Arduino Cloud daemon.

Connectivity, provisioning and the cloud handshake are owned by the
``arduino-cloud-connector`` daemon running on the board; this brick exchanges
variable values with it over its localhost REST/SSE API. The public
interface (constructor, ``register``, attribute get/set, the ``on_write`` /
``on_read`` / ``on_run`` callbacks and the re-exported ``Location`` /
``Color`` / ``ColoredLight`` / ``DimmedLight`` / ``Schedule`` objects) is
unchanged from the previous ``arduino_iot_cloud``-based implementation.

Per-variable conflict resolution is selectable via the ``sync`` argument to
``register`` (``DEVICE_WINS`` / ``CLOUD_WINS`` / ``MOST_RECENT_WINS``,
default ``CLOUD_WINS``).

### Parameters

- **device_id** (*str*): Deprecated and ignored. The daemon owns the device
identity and provisioning.
- **secret** (*str*): Deprecated and ignored (see device_id).
- **server** (*str*): Deprecated and ignored. The daemon connects to the
cloud broker on the brick's behalf.
- **port** (*int*): Deprecated and ignored (see server).
- **daemon_url** (*str*) (optional): Base URL of the local daemon REST API.
If omitted, uses the ARDUINO_CLOUD_CONNECTOR_URL environment
variable, otherwise the daemon's UNIX socket
(http+unix://<ARDUINO_CLOUD_CONNECTOR_SOCKET or
/run/arduino-cloud-connector/daemon.sock>).

### Methods

#### `start()`

Mark the brick started and ensure every registered leaf is subscribed.

Subscription and the synchronous initial seed already happen in
``register``; this is a safety net that (re)subscribes anything not yet
listening — e.g. a leaf whose register-time subscribe failed.

#### `loop()`

Sample device→cloud callbacks (on_run / on_read) and publish per policy.

Each pass, for every registered object: run its poll callbacks when due
(every pass in ON_CHANGE mode, once per ``interval`` in timed mode), then
publish each scalar leaf via ``pump()`` (ON_CHANGE throttle or timed
republish). Scalar on_write fires immediately from the SSE handler; a
complex object's coalesced on_write (one call for the whole object) is
delivered here, once per pass.

#### `stop()`

Stop the brick and tear down the SSE listener threads.

#### `register(aiotobj: str | Any)`

Register a variable or object with the Arduino Cloud client.

##### Parameters

- **aiotobj** (*str | Any*): The variable name, or a cloud object
(Location/Color/ColoredLight/DimmedLight/
Schedule) to register.
- ****kwargs** (*Any*): value, on_read, on_write, on_run, args, sync
(DEVICE_WINS/CLOUD_WINS/MOST_RECENT_WINS) and interval.
``interval`` selects the device→cloud update policy,
like the C++ ``addProperty`` seconds argument:
``ON_CHANGE`` (default) publishes changes throttled to
~0.5s; a positive value publishes the current value
every N seconds (timed).

#### `get(name: str, default: Any)`

Return a registered variable's value, or default if unset/unknown.


---

## `Location` class

```python
class Location(name: str)
```


---

## `Color` class

```python
class Color(name: str)
```


---

## `ColoredLight` class

```python
class ColoredLight(name: str)
```


---

## `DimmedLight` class

```python
class DimmedLight(name: str)
```


---

## `Schedule` class

```python
class Schedule(name: str)
```

A cloud schedule (frm/to/len/msk). Computes its active state in on_run.

