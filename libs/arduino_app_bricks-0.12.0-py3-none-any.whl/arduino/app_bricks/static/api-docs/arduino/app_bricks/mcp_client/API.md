# mcp_client API Reference

## Index

- Class `HTTPEndpoint`
- Class `MCPClient`

---

## `HTTPEndpoint` class

```python
class HTTPEndpoint(name: str, url: str, headers: dict | None, token: str | None, auth: 'httpx.Auth | None')
```

A class to communicate with remote MCP server via HTTP protocol to perform various tasks.

### Parameters

- **name** (*str*): A unique name for the MCP endpoint configuration.
- **url** (*str*): The URL of the remote MCP server's /mcp endpoint (e.g., http://localhost:8080/mcp).
- **headers** (*dict*) (optional), default=None: Optional HTTP headers for authentication or other purposes. Defaults to None.
- **token** (*str*) (optional), default=None: Bearer token added as an ``Authorization: Bearer`` header. Defaults to None.
- **auth** (*httpx.Auth*) (optional), default=None: An httpx authentication object passed through to the HTTP client. Defaults to None.

### Methods

#### `to_conn()`

Build the connection configuration consumed by MultiServerMCPClient.

##### Returns

- (*dict*): A mapping of the endpoint name to its transport configuration.


---

## `MCPClient` class

```python
class MCPClient(endpoints: list[HTTPEndpoint], tool_name_prefix: bool)
```

A class to communicate with the MCP server to perform various tasks.

### Parameters

- **endpoints** (*list[HTTPEndpoint]*): A list of MCP endpoint configurations. Use the brick's HTTPEndpoint class
to create endpoint configurations.
- **tool_name_prefix** (*bool*) (optional), default=True: Whether to prefix tool names with the client name. Defaults to True.
- ****kwargs**: Additional keyword arguments to pass to the MultiServerMCPClient.

### Methods

#### `get_client()`

Get the underlying MultiServerMCPClient instance.

##### Returns

- (*MultiServerMCPClient*): The underlying MCP client instance.

#### `get_tools(include: Iterable[str] | None, exclude: Iterable[str] | None)`

Discover the tools exposed by the configured MCP servers.

The returned tools are LangChain ``BaseTool`` instances that can be passed directly to the LLM
bricks via their ``tools`` argument (e.g. ``CloudLLM(tools=mcp.get_tools())`` or
``LargeLanguageModel(tools=mcp.get_tools())``).

Filtering by name lets you curate a small, relevant subset, useful for models with a small
context window. Names are matched as fnmatch-style glob patterns, so both exact names and
wildcards work (e.g. ``files_*``, ``*_read``).

##### Parameters

- **include** (*Iterable[str]*) (optional): Keep only tools whose name matches one of these patterns
(exact names or globs). Defaults to None (keep all).
- **exclude** (*Iterable[str]*) (optional): Drop tools whose name matches one of these patterns
(exact names or globs). Defaults to None.

##### Returns

- (*list[BaseTool]*): The tools aggregated from every configured endpoint, after filtering.

#### `list_tools()`

Return a ``{tool_name: description}`` overview of the available tools.

Useful for discovery: see what each MCP server exposes to decide which tools to keep via
``get_tools(include=..., exclude=...)``. Use ``inspect_tool`` for a single tool's details.

##### Returns

- (*dict[str, str]*): Mapping of each tool's name to its description.

#### `inspect_tool(name: str)`

Return the details of a single tool, or None if no tool has that name.

##### Parameters

- **name** (*str*): The tool name, as returned by ``list_tools`` / ``get_tools``.

##### Returns

-: dict | None: ``{"name", "description", "parameters"}`` where ``parameters`` is the tool's
argument schema, or None if no tool matches ``name``.

