# cloud_llm API Reference

## Index

- Class `CloudLLM`
- Class `CloudModel`
- Class `CloudModelProvider`
- Class `ContentChunk`
- Class `MessagePersistence`
- Class `ReasoningChunk`
- Class `ReasoningEffort`
- Class `ReasoningStreamChunk`
- Class `SQLMessagePersistence`
- Class `WindowedChatMessageHistory`

---

## `CloudLLM` class

```python
class CloudLLM(api_key: str, model: Union[str, CloudModel], system_prompt: str, temperature: Optional[float], reasoning_effort: Union['ReasoningEffort', str, int, None], max_tool_loops: int, timeout: Optional[int], tools: Optional[Sequence[ToolLike]], callbacks: Any)
```

A Brick for interacting with cloud-based Large Language Models (LLMs).

This class wraps LangChain functionality to provide a simplified, unified interface
for chatting with models like Claude, GPT, and Gemini. It supports both synchronous
'one-shot' responses and streaming output, with optional conversational memory.

### Parameters

- **api_key** (*str*): The API access key for the target LLM service. Defaults to the
'API_KEY' environment variable.
- **model** (*Union[str, CloudModel]*): The model identifier. Accepts a `CloudModel`
enum member (e.g., `CloudModel.OPENAI_GPT`) or its corresponding raw string
value (e.g., `'openai:gpt-5-mini'`). Defaults to `CloudModel.ANTHROPIC_CLAUDE`.
To identify the model provider, you need to use prefixes like 'openai:', 'anthropic:', or 'google:'.
If no prefix is provided, the model will be defaulted to an OpenAI compatible model.
- **system_prompt** (*str*): A system-level instruction that defines the AI's persona
and constraints (e.g., "You are a helpful assistant"). Defaults to empty.
- **temperature** (*Optional[float]*): The sampling temperature between 0.0 and 1.0.
Higher values make output more random/creative; lower values make it more
deterministic. When ``None`` (default) no temperature is sent and each
provider's own default is used; this also avoids errors on models that
deprecated ``temperature`` (e.g. Anthropic Claude Sonnet 5+).
- **reasoning_effort** (*ReasoningEffort | str | int | None*): Optional default reasoning
effort applied to every ``chat``/``chat_stream_reasoning`` call that does not
pass its own. ``chat_stream`` is never affected: it always streams from the
plain model (chat completions on OpenAI) and yields answer text only. When
``None`` (default) nothing is added and the plain model is used. When set, the
reasoning-capable client (Responses API for OpenAI) is used so it works with
tools. It is never forwarded as a raw model argument (which would break tool
calling on OpenAI chat completions). Accepts a discrete level (`ReasoningEffort`
/ 'minimal'/'low'/'medium'/'high') or an integer token budget.
- **max_tool_loops** (*int*): The maximum number of consecutive tool-call loops
allowed during a single chat interaction. Defaults to 8.
- **timeout** (*Optional[int]*): The maximum duration in seconds to wait for a response before
timing out. Defaults to None.
- **callbacks** (*Any*): Optional callbacks for monitoring generation events.
- **tools** (*Sequence[ToolLike]*): BaseTool objects (from @tool or MCPClient.get_tools()) or plain
callables (auto-wrapped into tools). Defaults to None. On OpenAI reasoning models
from gpt-5.1 onwards, binding tools turns reasoning off on the plain path
(``chat`` without an effort, ``chat_stream``), since chat completions rejects
function tools while reasoning is active. To reason with tools, pass a
``reasoning_effort`` or use ``chat_stream_reasoning``, which go through the
Responses API.
- ****kwargs**: Additional arguments passed to the model constructor

### Raises

- **ValueError**: If `api_key` is not provided (empty string).

### Methods

#### `with_memory(max_messages: int, persistence: Union[bool, MessagePersistence, None])`

Enables conversational memory for this instance.

Configures the Brick to retain a window of previous messages, allowing the
AI to maintain context across multiple interactions. An optional persistence
backend stores the history so it can resume across restarts.

##### Parameters

- **max_messages** (*int*): The maximum number of messages.
- **persistence** (*bool | MessagePersistence | None*): Optional persistence backend.
`None` or `False` keep history in memory only (default behavior).
`True` instantiates a default `SQLMessagePersistence()`. Pass a
`MessagePersistence` implementation directly (e.g.
`SQLMessagePersistence(thread_id="user-42")`) for full control.

##### Returns

- (*CloudLLM*): The current instance, allowing for method chaining.

#### `get_client()`

Returns the underlying LangChain model instance.

This allows for advanced users to access the full capabilities of the model
directly, such as calling `generate()` or `stream()` with custom message formats.

##### Returns

- (*BaseChatModel*): The LangChain chat model instance used internally.

#### `chat(message: str, images: List[str | bytes], reasoning_effort: Union['ReasoningEffort', str, int, None])`

Sends a message to the AI and blocks until the complete response is received.

This method automatically manages conversation history if memory is enabled.

##### Parameters

- **message** (*str*): The input text prompt from the user.
- **images** (*List[str | bytes]*): Optional list of image file paths or raw bytes to include in the prompt.
- **reasoning_effort** (*ReasoningEffort | str | int | None*): Optional control over
how much the model reasons before answering. When ``None`` (default) the
behavior is unchanged and the base model is used. When provided, the
reasoning-capable client is used so the effort is applied, but only the
final answer text is returned (the chain-of-thought is not included). Pass
a discrete level (`ReasoningEffort` or one of 'minimal'/'low'/'medium'/'high')
or an explicit integer token budget (`-1` dynamic/unrestricted, `0` off,
`N>0` token budget), mapped to the provider's native knob. Requires an
OpenAI-compatible, Google Gemini, or Anthropic Claude reasoning model.

##### Returns

- (*str*): The complete text response generated by the AI.

##### Raises

- **RuntimeError**: If the internal chain is not initialized, the model does not
support reasoning, or the API request fails.
- **ValueError**: If `reasoning_effort` is not a supported level or budget.
- **TypeError**: If `reasoning_effort` is not a ReasoningEffort, str, int, or None.

#### `chat_stream(message: str, images: List[str | bytes])`

Sends a message to the AI and yields response tokens as they are generated.

This allows for processing or displaying the response in real-time (streaming).
The generation can be interrupted by calling `stop_stream()`.

The stream always comes from the plain model (chat completions on OpenAI) and each
yielded item is plain answer text: a `reasoning_effort` configured on the brick does
not apply here, and on OpenAI reasoning models from gpt-5.1 onwards with tools bound
reasoning is turned off (chat completions rejects tools while reasoning). Use
`chat_stream_reasoning` to stream the chain-of-thought.

##### Parameters

- **message** (*str*): The input text prompt from the user.
- **images** (*List[str | bytes]*): Optional list of image file paths or raw bytes to include in the prompt.

##### Returns

- (*str*): Chunks of text (tokens) from the AI response.

##### Raises

- **RuntimeError**: If the internal chain is not initialized or if the API request fails.
- **AlreadyGenerating**: If a streaming session is already active.

#### `chat_stream_reasoning(message: str, images: List[str | bytes], reasoning_effort: Union['ReasoningEffort', str, int, None])`

Sends a message and yields both reasoning and answer tokens as they are generated.

Unlike `chat_stream`, this method separates the model's internal reasoning
(chain-of-thought) from the final answer. Each yielded item is a
`ReasoningStreamChunk`: either a `ReasoningChunk` (chain-of-thought) or a
`ContentChunk` (final answer), both exposing a `content` text fragment.
Branch on the concrete type with `isinstance`.

This requires an OpenAI-compatible, Google Gemini, or Anthropic Claude
reasoning model. The generation can be interrupted by calling `stop_stream()`.

##### Parameters

- **message** (*str*): The input text prompt from the user.
- **images** (*List[str | bytes]*): Optional list of image file paths or raw bytes to include in the prompt.
- **reasoning_effort** (*ReasoningEffort | str | int | None*): How much the model
reasons. Pass a level ('minimal'/'low'/'medium'/'high') or an integer
token budget (`-1` unrestricted, `0` off, `N` tokens); either one is
mapped to the provider's own reasoning setting. `None` uses the model
default (Anthropic models get a default budget, since Claude does not
reason unless asked). Bools and numeric strings (e.g. '64') are rejected.

##### Returns

- (*ReasoningStreamChunk*): A `ReasoningChunk` or `ContentChunk` holding a `content` text fragment.

##### Raises

- **RuntimeError**: If the model is not initialized, does not support reasoning, or the API request fails.
- **ValueError**: If `reasoning_effort` is not a supported level or budget.
- **TypeError**: If `reasoning_effort` is not a ReasoningEffort, str, int, or None.
- **AlreadyGenerating**: If a streaming session is already active.

##### Examples

```python
```python
for chunk in llm.chat_stream_reasoning("Why is the sky blue?"):
    if isinstance(chunk, ReasoningChunk):
        print(f"[thinking] {chunk.content}", end="", flush=True)
    else:
        print(chunk.content, end="", flush=True)
```
```
#### `stop_stream()`

Signals the active streaming generation to stop.

This sets an internal flag that causes the `chat_stream` iterator to break
early. It has no effect if no stream is currently running.

#### `clear_memory()`

Clears the conversational memory history.

Resets the stored context. This is useful for starting a new conversation
topic without previous context interfering. Only applies if memory is enabled.


---

## `CloudModel` class

```python
class CloudModel()
```


---

## `CloudModelProvider` class

```python
class CloudModelProvider()
```


---

## `ContentChunk` class

```python
class ContentChunk()
```

A fragment of the model's final answer.


---

## `MessagePersistence` class

```python
class MessagePersistence()
```

Backend interface for persisting chat messages

### Methods

#### `load(limit: Optional[int])`

Return persisted messages, most-recent last.

`limit` caps how many of the most recent ones are returned (None = all).

#### `append(messages: List[BaseMessage])`

Persist `messages` in order.

#### `clear()`

Remove all persisted messages owned by this store.


---

## `ReasoningChunk` class

```python
class ReasoningChunk()
```

A fragment of the model's internal reasoning (chain-of-thought).


---

## `ReasoningEffort` class

```python
class ReasoningEffort()
```

Discrete reasoning effort levels for reasoning-capable models.

These map to each provider's native knob:
- OpenAI: `reasoning_effort`.
- Gemini 3+: `thinking_level`.
- Gemini 2.5: mapped to a `thinking_budget` token count (see `EFFORT_TO_BUDGET`).
- Anthropic (legacy): mapped to a `thinking` `budget_tokens` count (see `EFFORT_TO_BUDGET`).
- Anthropic (Opus 4.7+/Sonnet 5+): mapped to `output_config.effort` (see `ANTHROPIC_EFFORT_MAP`).

For fine-grained control, an explicit integer token budget can be passed
instead of a level (see `CloudLLM.chat_stream_reasoning`).


---

## `ReasoningStreamChunk` class

```python
class ReasoningStreamChunk()
```

Base type for chunks yielded by `CloudLLM.chat_stream_reasoning`.

Every chunk carries a `content` text fragment. Use `isinstance` checks to
distinguish the model's reasoning from its final answer:

```python
for chunk in llm.chat_stream_reasoning("..."):
    if isinstance(chunk, ReasoningChunk):
        ...  # chunk.content is part of the chain-of-thought
    elif isinstance(chunk, ContentChunk):
        ...  # chunk.content is part of the final answer
```


---

## `SQLMessagePersistence` class

```python
class SQLMessagePersistence(sql_store: Optional[SQLStore], thread_id: str, table_name: str)
```

Chat message persistence store backed by a SQLite table via the SQLStore brick.

Messages are keyed by `thread_id` to track separate conversations.

### Parameters

- **sql_store** (*SQLStore | None*): An already-instantiated SQLStore brick.
If None, a default `SQLStore("llm.db")` is created.
- **thread_id** (*str*): Identifier for the conversation thread. Use distinct values
to keep separate conversations in the same database.
- **table_name** (*str*): Name of the table that stores serialized messages.

### Methods

#### `load(limit: Optional[int])`

Return persisted messages in chronological order, capped to the last `limit`.


---

## `WindowedChatMessageHistory` class

```python
class WindowedChatMessageHistory(k: int, system_message: str, store: Optional[MessagePersistence])
```

A chat history store that automatically keeps a window of the last k messages.

### Methods

#### `get_messages()`

Get all messages in the history, including system message if set.

#### `clear()`

Clear the in-memory window and any persisted backend for this history.

